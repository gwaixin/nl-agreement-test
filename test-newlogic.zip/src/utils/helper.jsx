export const langToWord = (lang) => {

  let word = {
    en: 'English',
    fn: 'French'
  }

  return word[lang];

}